﻿using UnityEngine;
using System.Collections;

public class bullet_effects_normal : MonoBehaviour {
	public Rigidbody rb;

	private TrailRenderer tr;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		tr = GetComponent<TrailRenderer>();

		tr.time = .5f;

	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnCollisionEnter(Collision c) {
		Destroy(gameObject);
	}
}
