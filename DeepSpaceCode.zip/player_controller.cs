﻿using UnityEngine;
using System.Collections;

public class player_controller : MonoBehaviour {
	
	private Rigidbody rb;
	private float[] weaponsCds;
	private float[] weaponsCdsMax;
	public GameObject bullet_norm;
	public GameObject rocket;
	private Vector3 target;
	private float spd;

	private player_props props;
	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		props = GetComponent<player_props>();

		weaponsCds = new float[2];
		weaponsCdsMax = new float[weaponsCds.Length];
		weaponsCdsMax[0] = 0.05f;
		weaponsCdsMax[1] = 0.5f;
		weaponsCds[0] = weaponsCdsMax[0];
		weaponsCds[1] = weaponsCdsMax[1];
		target = Vector3.zero;

		spd = 10f;
	}
	
	// Update is called once per frame
	void Update () {
		if (weaponsCds[0] > 0f) {
			weaponsCds[0] -= Time.deltaTime;
		}

		if (weaponsCds[1] > 0f) {
			weaponsCds[1] -= Time.deltaTime;
		}
		
		target = getCursorPosition("gnd");
		target.y = transform.position.y;
		transform.LookAt(target, Vector3.up);	
	
		float dist = Mathf.Abs(Vector3.Distance(transform.position, target));
		if (Input.GetKey(KeyCode.W) && dist >= 2f) {
			if (Input.GetKey(KeyCode.LeftShift)) {
				rb.velocity = transform.forward * spd * 2;
			}
			else rb.velocity = transform.forward * spd;
		} else {
			rb.velocity = Vector3.zero;
		}

		if (Input.GetMouseButton(0) && weaponsCds[0] <= 0f) {
			weaponsCds[0] = weaponsCdsMax[0];
			spawnBullet();
		}

		if (Input.GetMouseButton(1) && weaponsCds[1] <= 0f) {
			if (Input.GetKey(KeyCode.LeftShift)) {
				weaponsCds[1] = weaponsCdsMax[1];
				spawnRocketWithTarget();
			} else {
				weaponsCds[1] = weaponsCdsMax[1];
				spawnRocketNoTarget();
			}
		}
	}

	void spawnBullet () {
		GameObject bullet = (GameObject)Instantiate(bullet_norm, transform.position + transform.forward * 2f, Quaternion.identity);
		bullet.GetComponent<Rigidbody>().AddForce(transform.forward * 100f);

		Destroy(bullet, 1f);
	}

	void spawnRocketNoTarget() {
		GameObject _rocket = (GameObject)Instantiate(rocket, transform.position + transform.forward * 2f, Quaternion.identity);
		rocket_script rsc = _rocket.GetComponent<rocket_script>();
		Vector3 targetPos = getCursorPosition("gnd", transform.position.y);
		rsc.SetTargetPosition(targetPos);
		rsc.SetSpeed(20f);

		Destroy(_rocket, 2f);
	}

	void spawnRocketWithTarget() {
		Vector3 mousePos = getCursorPosition("gnd", transform.position.y);
		Collider[] objs = Physics.OverlapSphere(mousePos, 1);
		// objs[0].gameObject.GetComponent<dmgScript_enemy>().dmg(props.DMG);

		Collider e = null;
		for (int i = 0; i < objs.Length; i++) {
			if (objs[i].tag == "enemy") {
				e = objs[i];
				break;
			}
		}

		if (e != null) {
			GameObject _rocket = (GameObject)Instantiate(rocket, transform.position + transform.forward * 2f, Quaternion.identity);
			rocket_script rsc = _rocket.GetComponent<rocket_script>();
			rsc.SetTarget(e.gameObject);
			rsc.SetSpeed(20f);

			Destroy(_rocket, 2f);
		}
	}

	Vector3 getCursorPosition(string tag="", float heightAdj = -1f) {
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
		RaycastHit hit;
		Physics.Raycast(ray, out hit);
		Vector3 target = Vector3.zero;
		if (tag == "") {
			target = hit.point;
		} else {
			if (hit.collider.gameObject.tag == tag) {
				target = hit.point;
			}
		}
		if (heightAdj != -1f) {
			target.y = heightAdj;
		}
		return target;
	}

	void SetSpeed(float spd) {
		this.spd = spd;
	}
}
