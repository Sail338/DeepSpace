﻿using UnityEngine;
using System.Collections;

public class em_properties_cls {
	public float ATK, DEF, SHLD;
	public float SPD, TSPD, MIN_DIST;
	public int DROCKET, SROCKET;
	public bool LASER, BULLET;

	public float[] WEPCDS;
	
	public void hi() {
		Debug.Log("hi");
	}
}
