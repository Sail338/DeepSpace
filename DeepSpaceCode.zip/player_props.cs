﻿using UnityEngine;
using System.Collections;

public class player_props : MonoBehaviour {
	// base stats
	public float HP; // health
	public float STR; // raw damage
	public float DEX; // raw speed
	public float STM; // duration
	
	// modifiers
	public float mDMG; // damage modifier
	public float mDEF; // defense modifier

	// derived stats
	public float CRIT; // HP * 0.1STM
	public float SHLD; // STR * 2 * mDEF / 2
	public float DEFN; // 1.5 *(HP + STM)
}
