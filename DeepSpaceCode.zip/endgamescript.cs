﻿using UnityEngine;
using System.Collections;

public class endgamescript : MonoBehaviour {

    // Use this for initialization
    public void LoadMain()
    {
        Application.LoadLevel(1);
    }
}
